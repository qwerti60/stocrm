from __future__ import annotations

import json
import threading
import time
import uuid
from pathlib import Path
from typing import Any

from app.config import settings

_LOCK = threading.Lock()
_PATH = Path(__file__).resolve().parent.parent / "data" / "week3.json"

_EMPTY: dict[str, Any] = {
    "chats": {},
    "vin": [],
    "bonuses": {},
    "warned": [],
    "campaigns": [],
    "shorts": [],
    "audience": {},
}

DEFAULT_PROMOS = [
    {
        "id": "seed-oil",
        "title": "Замена масла",
        "subtitle": "от 4 990 ₽ · масло + фильтр + работа",
        "badge": "Акция",
        "pinned": True,
        "kind": "promo",
    },
    {
        "id": "seed-diag",
        "title": "Диагностика VAG бесплатно",
        "subtitle": "При первом визите через приложение",
        "badge": "В приложении",
        "pinned": True,
        "kind": "promo",
    },
    {
        "id": "seed-tires",
        "title": "−20% на шиномонтаж",
        "subtitle": "До конца месяца, любой филиал",
        "badge": "Акция",
        "pinned": True,
        "kind": "promo",
    },
]

DEFAULT_SHORTS = [
    {"id": "s1", "title": "Ваш VAG в надёжных руках", "subtitle": "Сервис · запчасти · забота о VAG", "url": "", "poster": ""},
    {"id": "s2", "title": "Машина готова!", "subtitle": "Push, когда статус в STOCRM сменится", "url": "", "poster": ""},
    {"id": "s3", "title": "Замена масла от 4 990 ₽", "subtitle": "Масло + фильтр + работа", "url": "", "poster": ""},
    {"id": "s4", "title": "Подбор запчастей по VIN", "subtitle": "Заявка уходит менеджеру в админку", "url": "", "poster": ""},
]


def _load() -> dict[str, Any]:
    if not _PATH.is_file():
        return json.loads(json.dumps(_EMPTY))
    try:
        data = json.loads(_PATH.read_text(encoding="utf-8"))
    except Exception:
        return json.loads(json.dumps(_EMPTY))
    for k, v in _EMPTY.items():
        data.setdefault(k, json.loads(json.dumps(v)))
    return data


def _save(data: dict[str, Any]) -> None:
    _PATH.parent.mkdir(parents=True, exist_ok=True)
    tmp = _PATH.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(_PATH)


def thread_key(contact_id: Any, phone: str | None = None) -> str:
    try:
        cid = int(contact_id or 0)
    except (TypeError, ValueError):
        cid = 0
    if cid:
        return str(cid)
    return f"phone:{phone or '?'}"


def list_messages(key: str) -> list[dict[str, Any]]:
    with _LOCK:
        data = _load()
        return list(data["chats"].get(key, []))


def add_message(
    key: str,
    *,
    text: str,
    from_staff: bool,
    staff_name: str = "Егор",
    kind: str = "chat",
    phone: str = "",
    name: str = "",
) -> dict[str, Any]:
    msg = {
        "id": uuid.uuid4().hex[:12],
        "text": text.strip(),
        "from_staff": from_staff,
        "staff_name": staff_name if from_staff else "",
        "kind": kind,
        "created": int(time.time()),
        "phone": phone,
        "name": name,
    }
    with _LOCK:
        data = _load()
        data["chats"].setdefault(key, [])
        data["chats"][key].append(msg)
        meta = data.setdefault("meta", {})
        meta[key] = {"phone": phone or meta.get(key, {}).get("phone", ""), "name": name or meta.get(key, {}).get("name", "")}
        _save(data)
    return msg


def list_threads() -> list[dict[str, Any]]:
    with _LOCK:
        data = _load()
        meta = data.get("meta") or {}
        out = []
        for key, msgs in data["chats"].items():
            last = msgs[-1] if msgs else {}
            info = meta.get(key) or {}
            out.append(
                {
                    "key": key,
                    "phone": info.get("phone") or last.get("phone") or "",
                    "name": info.get("name") or last.get("name") or "",
                    "count": len(msgs),
                    "last": last.get("text") or "",
                    "last_at": last.get("created") or 0,
                    "from_staff": last.get("from_staff"),
                }
            )
        out.sort(key=lambda x: x["last_at"], reverse=True)
        return out


def add_vin(key: str, *, vin: str, part: str, phone: str = "", name: str = "") -> dict[str, Any]:
    row = {
        "id": uuid.uuid4().hex[:10],
        "key": key,
        "vin": vin.strip().upper(),
        "part": part.strip(),
        "phone": phone,
        "name": name,
        "created": int(time.time()),
        "status": "new",
    }
    with _LOCK:
        data = _load()
        data["vin"].insert(0, row)
        _save(data)
    add_message(key, text=f"VIN {row['vin']} · {row['part']}", from_staff=False, kind="vin", phone=phone, name=name)
    add_message(
        key,
        text="Заявку на подбор получили, уточним наличие и напишем. Это не списание со склада.",
        from_staff=True,
        staff_name="Егор",
        kind="vin",
        phone=phone,
        name=name,
    )
    return row


def list_vin() -> list[dict[str, Any]]:
    with _LOCK:
        return list(_load()["vin"])


def money(v: Any) -> int:
    if v is None or v is False:
        return 0
    s = str(v).replace(" ", "").replace("\xa0", "").replace(",", ".")
    try:
        return int(round(float(s)))
    except (TypeError, ValueError):
        return 0


def is_bonus_offer(status_id: int, title: str) -> bool:
    t = (title or "").lower()
    if status_id in (4, 5, 5648) or any(x in t for x in ("отказ", "мусор", "не приехал")):
        return False
    if status_id in (6, 6845) or any(x in t for x in ("успешн", "выполнен")):
        return True
    return False


def sync_bonuses(contact_id: int, offers: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Начислить 5% один раз на закрытый ЗН с суммой. Возвращает новые записи."""
    pct = max(int(settings.bonus_percent or 5), 1)
    expire_days = max(int(settings.bonus_expire_days or 365), 1)
    key = str(int(contact_id))
    created: list[dict[str, Any]] = []
    with _LOCK:
        data = _load()
        book: dict[str, Any] = data["bonuses"].setdefault(key, {"events": []})
        seen = {str(e.get("offer_id")) for e in book["events"] if e.get("offer_id") and int(e.get("delta") or 0) > 0}
        now = int(time.time())
        for o in offers:
            oid = o.get("OFFER_ID") or o.get("id")
            if oid is None:
                continue
            sid = int(o.get("OFFER_STATUS_ID") or o.get("status_id") or 0)
            title = str(o.get("STATUS_NAME") or o.get("status") or "")
            if not is_bonus_offer(sid, title):
                continue
            amount = money(o.get("OFFER_SUM") or o.get("WORKS_SUM") or o.get("sum") or o.get("works_sum"))
            if amount <= 0:
                continue
            if str(oid) in seen:
                continue
            delta = max(int(round(amount * pct / 100)), 1)
            ev = {
                "id": uuid.uuid4().hex[:10],
                "title": f"Начисление {pct}%",
                "delta": delta,
                "when": now,
                "note": f"ЗН № {oid} · {title} · {amount} ₽",
                "offer_id": oid,
                "expires": now + expire_days * 86400,
            }
            book["events"].insert(0, ev)
            seen.add(str(oid))
            created.append(ev)
        _save(data)
    return created


def bonus_statement(contact_id: int) -> dict[str, Any]:
    key = str(int(contact_id))
    warn_days = max(int(settings.bonus_warn_days or 5), 1)
    now = int(time.time())
    with _LOCK:
        events = list((_load()["bonuses"].get(key) or {}).get("events") or [])
    balance = sum(int(e.get("delta") or 0) for e in events)
    expiring = []
    for e in events:
        exp = int(e.get("expires") or 0)
        if int(e.get("delta") or 0) > 0 and exp and 0 < exp - now <= warn_days * 86400:
            expiring.append(e)
    return {
        "balance": balance,
        "percent": int(settings.bonus_percent or 5),
        "expire_days": int(settings.bonus_expire_days or 365),
        "warn_days": warn_days,
        "events": events,
        "expiring": expiring,
    }


def take_expiry_warnings(contact_id: int) -> list[dict[str, Any]]:
    """События, по которым ещё не слали push о сгорании."""
    stmt = bonus_statement(contact_id)
    due = stmt["expiring"]
    if not due:
        return []
    with _LOCK:
        data = _load()
        warned: list[str] = data.setdefault("warned", [])
        fresh = []
        for e in due:
            wid = f"exp:{contact_id}:{e.get('id')}"
            if wid in warned:
                continue
            warned.append(wid)
            fresh.append(e)
        _save(data)
    return fresh


def touch_audience(contact_id: Any, phone: str = "", name: str = "") -> None:
    try:
        cid = int(contact_id or 0)
    except (TypeError, ValueError):
        cid = 0
    if not cid:
        return
    key = str(cid)
    with _LOCK:
        data = _load()
        row = data.setdefault("audience", {}).setdefault(key, {})
        row["contact_id"] = cid
        row["phone"] = phone or row.get("phone") or ""
        row["name"] = name or row.get("name") or ""
        row["last_seen"] = int(time.time())
        _save(data)


def list_audience() -> list[dict[str, Any]]:
    with _LOCK:
        rows = list((_load().get("audience") or {}).values())
    rows.sort(key=lambda x: int(x.get("last_seen") or 0), reverse=True)
    return rows


def add_campaign(
    *,
    title: str,
    body: str,
    badge: str = "Акция",
    segment: str = "all",
    branch_id: str = "",
    pin: bool = True,
) -> dict[str, Any]:
    row = {
        "id": uuid.uuid4().hex[:10],
        "title": title.strip(),
        "body": body.strip(),
        "subtitle": body.strip(),
        "badge": (badge or "Акция").strip() or "Акция",
        "segment": (segment or "all").strip() or "all",
        "branch_id": str(branch_id or "").strip(),
        "pinned": bool(pin),
        "created": int(time.time()),
        "sent": 0,
        "kind": "promo",
    }
    with _LOCK:
        data = _load()
        data.setdefault("campaigns", []).insert(0, row)
        _save(data)
    return row


def mark_campaign_sent(cid: str, count: int) -> None:
    with _LOCK:
        data = _load()
        for row in data.get("campaigns") or []:
            if row.get("id") == cid:
                row["sent"] = int(count)
                row["sent_at"] = int(time.time())
                break
        _save(data)


def list_campaigns() -> list[dict[str, Any]]:
    with _LOCK:
        return list(_load().get("campaigns") or [])


def list_promos() -> list[dict[str, Any]]:
    own = [c for c in list_campaigns() if c.get("pinned") or c.get("sent")]
    if own:
        return own
    return list(DEFAULT_PROMOS)


def add_short(*, title: str, subtitle: str = "", url: str = "", poster: str = "") -> dict[str, Any]:
    row = {
        "id": uuid.uuid4().hex[:10],
        "title": title.strip(),
        "subtitle": subtitle.strip(),
        "url": url.strip(),
        "poster": poster.strip(),
        "created": int(time.time()),
    }
    with _LOCK:
        data = _load()
        data.setdefault("shorts", []).insert(0, row)
        _save(data)
    return row


def list_shorts() -> list[dict[str, Any]]:
    with _LOCK:
        own = list(_load().get("shorts") or [])
    if own:
        return own + DEFAULT_SHORTS
    return list(DEFAULT_SHORTS)
