from __future__ import annotations

import threading
import time
import uuid
from typing import Any

import httpx

from app.config import settings

_lock = threading.Lock()
last_status: dict[tuple[int, int], int] = {}
inbox: dict[int, list[dict[str, Any]]] = {}
devices: dict[int, list[str]] = {}
seen_contacts: set[int] = set()


def register_device(contact_id: int, token: str) -> None:
    if not token or not contact_id:
        return
    with _lock:
        lst = devices.setdefault(int(contact_id), [])
        if token not in lst:
            lst.append(token)


def add_note(contact_id: int, title: str, body: str, offer_id: Any = None, kind: str = "ready") -> dict[str, Any]:
    note = {
        "id": uuid.uuid4().hex[:12],
        "title": title,
        "body": body,
        "offer_id": offer_id,
        "created": int(time.time()),
        "read": False,
        "kind": kind,
    }
    with _lock:
        inbox.setdefault(int(contact_id), []).insert(0, note)
        tokens = list(devices.get(int(contact_id), []))
    for tok in tokens:
        send_fcm(tok, title, body)
    return note


def list_notes(contact_id: int) -> list[dict[str, Any]]:
    with _lock:
        return list(inbox.get(int(contact_id), []))


def known_contact_ids() -> list[int]:
    with _lock:
        ids = set(int(c) for c in inbox.keys())
        ids.update(int(c) for c in seen_contacts)
        ids.update(int(c) for c in devices.keys())
    return sorted(ids)


def mark_read(contact_id: int, note_id: str) -> None:
    with _lock:
        for n in inbox.get(int(contact_id), []):
            if n["id"] == note_id:
                n["read"] = True


def is_ready_status(status_id: int | None, title: str) -> bool:
    t = (title or "").lower()
    if status_id in (6, 17953, 6845):
        return True
    return any(x in t for x in ("готов", "успешн", "выполнен"))


def poll_once(stocrm: Any, contact_ids: list[int]) -> int:
    created = 0
    unique = sorted({int(c) for c in contact_ids if c})
    for cid in unique:
        first = cid not in seen_contacts
        try:
            offers = stocrm.offers_by_contact(cid)
        except Exception:
            continue
        for o in offers:
            oid = int(o.get("OFFER_ID") or 0)
            if not oid:
                continue
            sid = int(o.get("OFFER_STATUS_ID") or 0)
            title = str(o.get("STATUS_NAME") or "")
            key = (cid, oid)
            with _lock:
                prev = last_status.get(key)
                last_status[key] = sid
            if first:
                continue
            became_ready = prev is not None and prev != sid and is_ready_status(sid, title) and not is_ready_status(prev, "")
            if became_ready:
                add_note(cid, "Ваша машина готова!", f"{title}. Заберите авто в сервисе.", oid)
                created += 1
        seen_contacts.add(cid)
    return created


def send_fcm(token: str, title: str, body: str) -> None:
    key = (settings.fcm_server_key or "").strip()
    if not key or not token:
        return
    try:
        httpx.post(
            "https://fcm.googleapis.com/fcm/send",
            headers={"Authorization": f"key={key}", "Content-Type": "application/json"},
            json={
                "to": token,
                "notification": {"title": title, "body": body, "sound": "default"},
                "data": {"type": "ready"},
            },
            timeout=8.0,
        )
    except Exception:
        return
