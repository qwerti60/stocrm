from __future__ import annotations

import asyncio
import re
import secrets
from datetime import date, datetime
from pathlib import Path
from typing import Any
from urllib.parse import quote

from contextlib import asynccontextmanager

from fastapi import FastAPI, Header, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

from app.config import settings
from app.notify import add_note, known_contact_ids, list_notes, mark_read, poll_once, register_device
from app.site import mount_site
from app.slots import MSK, build_slots, day_bounds, unix
from app.store import (
    add_campaign,
    add_message,
    add_short,
    add_vin,
    bonus_statement,
    list_audience,
    list_campaigns,
    list_messages,
    list_promos,
    list_shorts,
    list_threads,
    list_vin,
    mark_campaign_sent,
    sync_bonuses,
    take_expiry_warnings,
    thread_key,
    touch_audience,
)
from app.stocrm import StoCrmError, stocrm


def _week_poll(cids: list[int]) -> None:
    poll_once(stocrm, cids)
    for cid in cids:
        try:
            offers = stocrm.offers_by_contact(cid)
            sync_bonuses(cid, offers)
            for ev in take_expiry_warnings(cid):
                add_note(
                    cid,
                    "Бонусы скоро сгорят",
                    f"{ev.get('delta')} ₽ сгорят в течение {settings.bonus_warn_days} дн.",
                    ev.get("offer_id"),
                    kind="bonus",
                )
        except Exception:
            continue


async def _poll_loop() -> None:
    await asyncio.sleep(20)
    interval = max(int(settings.poll_interval_sec or 90), 30)
    while True:
        try:
            cids = [int(u["contact_id"]) for u in sessions.values() if u.get("contact_id")]
            await asyncio.to_thread(_week_poll, cids)
        except asyncio.CancelledError:
            raise
        except Exception:
            pass
        await asyncio.sleep(interval)


@asynccontextmanager
async def lifespan(_: FastAPI):
    task = asyncio.create_task(_poll_loop())
    try:
        yield
    finally:
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass
        stocrm.close()


app = FastAPI(
    title="VAG Market BFF",
    version="0.4.0",
    lifespan=lifespan,
    docs_url="/internal/swagger" if settings.is_dev_secret else None,
    redoc_url=None,
    openapi_url="/internal/openapi.json" if settings.is_dev_secret else None,
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

otp_box: dict[str, str] = {}
sessions: dict[str, dict[str, Any]] = {}


def digits_phone(raw: str) -> str:
    d = re.sub(r"\D", "", raw)
    if d.startswith("8") and len(d) == 11:
        d = "7" + d[1:]
    if d.startswith("7") and len(d) == 11:
        return d
    if len(d) == 10:
        return "7" + d
    raise HTTPException(400, "Нужен номер РФ, 10 цифр после +7")


def require_user(authorization: str | None) -> dict[str, Any]:
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(401, "Нет сессии")
    token = authorization.split(" ", 1)[1].strip()
    user = sessions.get(token)
    if not user:
        raise HTTPException(401, "Сессия истекла")
    return user


def require_admin(x_bff_secret: str | None) -> None:
    key = settings.admin_key
    if settings.is_dev_secret and not (x_bff_secret or "").strip():
        return
    if not key or x_bff_secret != key:
        raise HTTPException(401, "Нет доступа в админку")


def _user_key(user: dict[str, Any]) -> str:
    return thread_key(user.get("contact_id"), user.get("phone"))


def _car_out(c: dict[str, Any]) -> dict[str, Any]:
    title = c.get("TITLE") or " ".join(x for x in (c.get("BRAND_NAME"), c.get("MODEL_NAME")) if x).strip()
    return {
        "id": int(c.get("CAR_PROFILE_ID") or 0),
        "title": title,
        "brand": c.get("BRAND_NAME"),
        "model": c.get("MODEL_NAME"),
        "generation": c.get("GENERATION_NAME"),
        "year": c.get("YEAR"),
        "vin": c.get("VIN"),
        "plate": c.get("LICENSE_PLATE"),
        "mileage": c.get("MILEAGE"),
        "sold": c.get("SOLD"),
        "color": c.get("COLOR"),
    }


def _offer_out(o: dict[str, Any], works: list[str] | None = None) -> dict[str, Any]:
    status_id = int(o.get("OFFER_STATUS_ID") or 0)
    title = str(o.get("STATUS_NAME") or "")
    stage = _stage(status_id, title)
    is_final = _is_final(status_id, title)
    is_ready = stage == "ready" or status_id in (6, 17953, 6845)
    is_history = stage in ("closed", "done") or (stage == "ready" and status_id != 17953)
    return {
        "id": o.get("OFFER_ID"),
        "status": title,
        "status_id": status_id or None,
        "stage": stage,
        "is_final": is_final,
        "is_ready": is_ready,
        "is_history": is_history,
        "board": o.get("BOARD_NAME"),
        "sum": o.get("OFFER_SUM"),
        "works_sum": o.get("WORKS_SUM"),
        "car": o.get("CAR_TITLE"),
        "branch": o.get("OFFER_CUSTOMER_NAME"),
        "branch_id": o.get("CUSTOMER_ID"),
        "created": o.get("OFFER_DATE_CREATE_FRONTEND_TIMESTAMP"),
        "calendar_from": o.get("CALENDAR_RECORD_DATE_FROM"),
        "calendar_to": o.get("CALENDAR_RECORD_DATE_TO"),
        "works": works or [],
        "steps": _funnel_steps(status_id, title),
    }


def _stage(status_id: int, title: str) -> str:
    t = (title or "").lower()
    if status_id in (4, 5, 5648) or any(x in t for x in ("отказ", "мусор", "не приехал")):
        return "closed"
    if status_id == 6 or "успешн" in t or status_id == 17953 or "готов" in t:
        return "ready"
    if status_id == 6845 or "выполнен" in t:
        return "done"
    if status_id in (2, 6844) or "работ" in t:
        return "work"
    if status_id in (5628,) or "записан" in t:
        return "booked"
    return "inbox"


def _is_final(status_id: int, title: str) -> bool:
    t = (title or "").lower()
    if status_id in (4, 5, 6, 5648):
        return True
    try:
        for row in stocrm.offer_statuses():
            sid = int(row.get("OFFER_STATUS_ID") or row.get("STATUS_ID") or row.get("ID") or 0)
            if sid == status_id:
                return str(row.get("IS_FINAL") or "").upper() == "Y"
    except Exception:
        pass
    return any(x in t for x in ("успешн", "отказ", "мусор"))


def _funnel_steps(status_id: int, title: str) -> list[dict[str, Any]]:
    t = (title or "").lower()
    ready = status_id in (6, 17953) or "готов" in t or "успешн" in t
    done = ready or status_id == 6845 or "выполнен" in t
    work = done or status_id in (2, 6844) or "работ" in t or "ожидан" in t
    booked = work or status_id in (5628, 17953) or "записан" in t
    if status_id in (4, 5, 5648) or any(x in t for x in ("отказ", "мусор", "не приехал")):
        return [
            {"title": "Заявка принята", "done": True},
            {"title": title or "Закрыто", "done": True, "detail": "сделка закрыта"},
        ]
    return [
        {"title": "Заявка принята", "done": True},
        {"title": "Записан в сервис", "done": booked},
        {"title": "В работе", "done": work},
        {"title": "Выполнен", "done": done},
        {
            "title": "Машина готова",
            "done": ready,
            "detail": "«Ваша машина готова!»" if ready else "Push при смене статуса в CRM",
        },
    ]


class PhoneIn(BaseModel):
    phone: str


class OtpIn(BaseModel):
    phone: str
    code: str


class BookingIn(BaseModel):
    car_id: int | None = None
    branch_id: str | None = None
    when: str | None = None
    comment: str = Field(default="Запись из приложения VAG Market")


class DeviceIn(BaseModel):
    fcm_token: str = ""


class ChatIn(BaseModel):
    text: str


class VinIn(BaseModel):
    vin: str
    part: str


class StaffReplyIn(BaseModel):
    text: str
    staff_name: str = "Егор"


class CampaignIn(BaseModel):
    title: str
    body: str
    badge: str = "Акция"
    segment: str = "all"
    branch_id: str = ""
    pin: bool = True


class ShortIn(BaseModel):
    title: str
    subtitle: str = ""
    url: str = ""
    poster: str = ""


@app.get("/health")
def health() -> dict[str, Any]:
    return {
        "ok": True,
        "stocrm_domain": settings.stocrm_domain,
        "sid_set": bool(settings.stocrm_sid),
        "board_id": settings.stocrm_board_id,
        "week": 4,
        "fcm": bool((settings.fcm_server_key or "").strip()),
    }


@app.get("/internal/stocrm/probe")
def probe(x_bff_secret: str | None = Header(default=None, alias="X-BFF-Secret")) -> dict[str, Any]:
    """Карта методов на боевом SID. Снаружи только с заголовком X-BFF-Secret."""
    if not settings.is_dev_secret and x_bff_secret != settings.bff_secret:
        raise HTTPException(404, "Not found")
    checks = [
        ("contacts/get_from_filter", {"FILTER": {}, "PAGE": 1, "LIMIT": 3}),
        ("car_profile/get_filtered_profiles", {"FILTER": {}, "PAGE": 1, "LIMIT": 3}),
        ("offers/get_from_filter", {"FILTER": {"BOARD_ID": settings.stocrm_board_id or 1097}, "PAGE": 1, "LIMIT": 2}),
        ("offer/all_statuses", {"BOARD_ID": settings.stocrm_board_id or 1097}),
        ("work/get_filtered", {"FILTER": {}, "PAGE": 1, "LIMIT": 3}),
        ("calendar/card/get", {"CUSTOMER_ID": 2113, "DATE": unix(datetime.now(MSK).replace(hour=0, minute=0, second=0, microsecond=0))}),
        ("shift/get_filtered", {"FILTER": {}, "PAGE": 1, "LIMIT": 3}),
        ("customers/get_filtered", {"FILTER": {}, "PAGE": 1, "LIMIT": 20}),
        ("legal_entities/get_from_filter", {"FILTER": {"IS_OUR": "Y"}, "PAGE": 1, "LIMIT": 10}),
        ("contact/new", None),
    ]
    results = []
    for path, payload in checks:
        if payload is None:
            results.append({"ok": False, "path": path, "skipped": "мутирующий метод, не дергаем в probe"})
            continue
        results.append(stocrm.probe(path, payload))
    return {"base": settings.base_url, "results": results}


@app.post("/v1/auth/otp/request")
def otp_request(body: PhoneIn) -> dict[str, str]:
    phone = digits_phone(body.phone)
    otp_box[phone] = settings.dev_otp_code
    return {"status": "sent", "hint": "прототип: код 1234"}


@app.post("/v1/auth/otp/confirm")
def otp_confirm(body: OtpIn) -> dict[str, Any]:
    phone = digits_phone(body.phone)
    if otp_box.get(phone) != body.code.strip():
        raise HTTPException(400, "Неверный код")
    contacts = []
    crm_error = None
    try:
        variants = [phone, phone[1:], f"+{phone}"]
        seen: set[int] = set()
        for v in variants:
            for c in stocrm.contacts_by_phone(v):
                cid = int(c.get("CONTACT_ID") or c.get("ID") or 0)
                if cid and cid not in seen:
                    seen.add(cid)
                    contacts.append(c)
    except Exception as e:
        crm_error = str(e)
    contact = contacts[0] if contacts else None
    token = secrets.token_urlsafe(24)
    cid = int(contact.get("CONTACT_ID") or contact.get("ID") or 0) if contact else None
    sessions[token] = {
        "phone": phone,
        "contact_id": cid,
        "name": (contact or {}).get("TITLE") or (contact or {}).get("FIRSTNAME") or "Клиент",
        "contact": contact,
    }
    if cid:
        touch_audience(cid, phone=phone, name=str(sessions[token]["name"] or ""))
    return {
        "token": token,
        "phone": phone,
        "contact_id": cid,
        "name": sessions[token]["name"],
        "found_in_crm": contact is not None,
        "crm_error": crm_error,
    }


@app.get("/v1/me")
def me(authorization: str | None = Header(default=None)) -> dict[str, Any]:
    user = require_user(authorization)
    return {
        "phone": user.get("phone"),
        "contact_id": user.get("contact_id"),
        "name": user.get("name"),
    }


@app.get("/v1/garage")
def garage(authorization: str | None = Header(default=None)) -> dict[str, Any]:
    user = require_user(authorization)
    cid = user.get("contact_id")
    if not cid:
        return {"cars": [], "reason": "контакт не найден в STOCRM по телефону"}
    cars = stocrm.cars_by_contact(int(cid))
    return {"cars": [_car_out(c) for c in cars]}


@app.get("/v1/visits")
def visits(authorization: str | None = Header(default=None)) -> dict[str, Any]:
    user = require_user(authorization)
    cid = user.get("contact_id")
    if not cid:
        return {"offers": []}
    offers = stocrm.offers_by_contact(int(cid))
    works = stocrm.works_index([int(o.get("OFFER_ID") or 0) for o in offers if o.get("OFFER_ID")])
    return {"offers": [_offer_out(o, works.get(int(o.get("OFFER_ID") or 0), [])) for o in offers]}


@app.get("/v1/slots")
def slots(
    branch_id: str = Query(..., description="CUSTOMER_ID филиала"),
    day: str = Query(..., alias="date", description="YYYY-MM-DD, Europe/Moscow"),
) -> dict[str, Any]:
    if not branch_id.isdigit():
        raise HTTPException(400, "branch_id — числовой CUSTOMER_ID филиала")
    try:
        parsed = date.fromisoformat(day)
    except ValueError:
        raise HTTPException(400, "date в формате YYYY-MM-DD")
    customer_id = int(branch_id)
    midnight = datetime.combine(parsed, datetime.min.time(), tzinfo=MSK)
    try:
        cards = stocrm.calendar_cards(customer_id, unix(midnight))
        posts = stocrm.calendar_posts(customer_id)
        posts = [p for p in posts if str(p.get("CUSTOMER_ID") or customer_id) == str(customer_id)]
    except StoCrmError as e:
        raise HTTPException(502, f"Календарь STOCRM: {str(e)[:300]}") from e
    post_ids = [p.get("POST_ID") or p.get("ID") for p in posts]
    built = build_slots(day=parsed, cards=cards, post_ids=post_ids)
    start, end = day_bounds(parsed)
    return {
        "branch_id": customer_id,
        "date": parsed.isoformat(),
        "hours": f"{start.strftime('%H:%M')}–{end.strftime('%H:%M')}",
        "posts": len({p for p in post_ids if p not in (None, "", 0, "0")}),
        "busy_cards": len(cards),
        "slots": built,
        "note": "Свободно, если занятых постов меньше ёмкости. Заявка не бронирует пост до подтверждения приёмкой.",
    }


@app.get("/v1/branches")
def branches() -> dict[str, Any]:
    rows = []
    for c in stocrm.customers():
        if str(c.get("ACTIVE") or "Y").upper() in ("N", "0", "FALSE"):
            continue
        rows.append(
            {
                "id": c.get("CUSTOMER_ID"),
                "name": c.get("CUSTOMER_NAME"),
                "address": c.get("ADDRESS") or "",
                "phone": _phone_out(c.get("PHONES")),
                "site": c.get("SITE"),
                "city": c.get("CITY_NAME") or "",
                "work_time": _work_time_out(c.get("WORK_TIME_STRING") or c.get("WORK_TIME")),
                "maps_url": _maps_url(c.get("ADDRESS") or "", c.get("CUSTOMER_NAME") or "", c.get("CITY_NAME") or ""),
            }
        )
    return {"branches": rows}


@app.post("/v1/bookings")
def bookings(body: BookingIn, authorization: str | None = Header(default=None)) -> dict[str, Any]:
    user = require_user(authorization)
    cid = user.get("contact_id")
    if not cid:
        raise HTTPException(409, "Клиент не найден в STOCRM. Сначала заведите контакт с этим телефоном в CRM.")
    comment = body.comment.strip() or "Запись из приложения VAG Market"
    if body.when:
        comment = f"{comment}\nСлот: {body.when}"
    if body.branch_id:
        comment = f"{comment}\nФилиал: {body.branch_id}"
    try:
        created = stocrm.offer_new(
            int(cid),
            comment=comment,
            car_id=body.car_id if body.car_id else None,
            customer_id=int(body.branch_id) if body.branch_id and str(body.branch_id).isdigit() else None,
        )
    except StoCrmError as e:
        raise HTTPException(502, f"STOCRM не принял заявку: {str(e)[:300]}") from e
    offer_id = _offer_id(created)
    return {
        "ok": True,
        "message": "Вы записаны, ожидайте подтверждения звонка или сообщения",
        "offer_id": offer_id,
    }


@app.post("/v1/devices")
def devices(body: DeviceIn, authorization: str | None = Header(default=None)) -> dict[str, Any]:
    user = require_user(authorization)
    cid = user.get("contact_id")
    if not cid:
        raise HTTPException(409, "Нет контакта в CRM")
    if body.fcm_token.strip():
        register_device(int(cid), body.fcm_token.strip())
    return {"ok": True, "fcm": bool((settings.fcm_server_key or "").strip())}


@app.get("/v1/notifications")
def notifications(authorization: str | None = Header(default=None)) -> dict[str, Any]:
    user = require_user(authorization)
    cid = user.get("contact_id")
    if not cid:
        return {"items": []}
    return {"items": list_notes(int(cid)), "fcm": bool((settings.fcm_server_key or "").strip())}


@app.post("/v1/notifications/{note_id}/read")
def notification_read(note_id: str, authorization: str | None = Header(default=None)) -> dict[str, Any]:
    user = require_user(authorization)
    cid = user.get("contact_id")
    if cid:
        mark_read(int(cid), note_id)
    return {"ok": True}


@app.post("/v1/notifications/test")
def notification_test(authorization: str | None = Header(default=None)) -> dict[str, Any]:
    """QA: имитация push «машина готова» без смены статуса в CRM."""
    user = require_user(authorization)
    cid = user.get("contact_id")
    if not cid:
        raise HTTPException(409, "Нет контакта в CRM")
    note = add_note(int(cid), "Ваша машина готова!", "Тест: заберите авто в сервисе.")
    return {"ok": True, "item": note}


@app.get("/v1/chat")
def chat_get(authorization: str | None = Header(default=None)) -> dict[str, Any]:
    user = require_user(authorization)
    msgs = list_messages(_user_key(user))
    staff = next((m.get("staff_name") for m in reversed(msgs) if m.get("from_staff") and m.get("staff_name")), "Егор")
    return {"messages": msgs, "staff_name": staff or "Егор"}


@app.post("/v1/chat")
def chat_post(body: ChatIn, authorization: str | None = Header(default=None)) -> dict[str, Any]:
    user = require_user(authorization)
    text = body.text.strip()
    if not text:
        raise HTTPException(400, "Пустое сообщение")
    msg = add_message(
        _user_key(user),
        text=text,
        from_staff=False,
        phone=str(user.get("phone") or ""),
        name=str(user.get("name") or ""),
    )
    return {"ok": True, "item": msg}


@app.post("/v1/vin")
def vin_post(body: VinIn, authorization: str | None = Header(default=None)) -> dict[str, Any]:
    user = require_user(authorization)
    vin = body.vin.strip()
    part = body.part.strip()
    if len(vin) < 11 or not part:
        raise HTTPException(400, "Нужны VIN и наименование запчасти")
    row = add_vin(
        _user_key(user),
        vin=vin,
        part=part,
        phone=str(user.get("phone") or ""),
        name=str(user.get("name") or ""),
    )
    return {"ok": True, "item": row, "message": "Заявка ушла менеджеру. Это не витрина склада."}


@app.get("/v1/bonuses")
def bonuses_get(authorization: str | None = Header(default=None)) -> dict[str, Any]:
    user = require_user(authorization)
    cid = user.get("contact_id")
    if not cid:
        return {"balance": 0, "events": [], "reason": "контакт не найден в CRM"}
    try:
        sync_bonuses(int(cid), stocrm.offers_by_contact(int(cid)))
    except Exception:
        pass
    return bonus_statement(int(cid))


@app.get("/v1/recommendations")
def recommendations_get(authorization: str | None = Header(default=None)) -> dict[str, Any]:
    user = require_user(authorization)
    cid = user.get("contact_id")
    items: list[dict[str, Any]] = []
    if cid:
        try:
            offers = stocrm.offers_by_contact(int(cid))
            works = stocrm.works_index([int(o.get("OFFER_ID") or 0) for o in offers if o.get("OFFER_ID")])
            for o in offers:
                mapped = _offer_out(o, works.get(int(o.get("OFFER_ID") or 0), []))
                if mapped.get("is_history"):
                    continue
                for w in mapped.get("works") or []:
                    items.append({"title": w, "subtitle": mapped.get("status") or "открытая заявка", "offer_id": mapped.get("id")})
            cars = stocrm.cars_by_contact(int(cid))
            for c in cars:
                km = c.get("MILEAGE")
                nxt = c.get("NEXT_SERVICE_KM") or c.get("TO_MILEAGE")
                title = c.get("TITLE") or " ".join(x for x in (c.get("BRAND_NAME"), c.get("MODEL_NAME")) if x)
                if nxt and km:
                    left = int(nxt) - int(km)
                    items.append({"title": f"ТО {title}: {'пора записываться' if left <= 0 else f'через {left} км'}", "subtitle": "пробег из карточки авто"})
        except Exception:
            pass
    return {"items": items, "empty": not items}


@app.get("/v1/promos")
def promos_get() -> dict[str, Any]:
    return {"items": list_promos()}


@app.get("/v1/shorts")
def shorts_get() -> dict[str, Any]:
    return {"items": list_shorts()}


@app.get("/v1/search")
def search_get(q: str = Query(""), authorization: str | None = Header(default=None)) -> dict[str, Any]:
    needle = (q or "").strip().lower()
    hits: list[dict[str, Any]] = []
    user = None
    if authorization:
        try:
            user = require_user(authorization)
        except HTTPException:
            user = None
    if not needle:
        return {"q": q, "items": []}
    cid = int(user["contact_id"]) if user and user.get("contact_id") else 0
    if cid:
        try:
            for c in stocrm.cars_by_contact(cid):
                mapped = _car_out(c)
                blob = " ".join(str(mapped.get(k) or "") for k in ("title", "brand", "model", "plate", "vin")).lower()
                if needle in blob:
                    hits.append({"kind": "car", "title": mapped.get("title") or "Авто", "subtitle": mapped.get("plate") or "", "screen": "garage"})
        except Exception:
            pass
        try:
            offers = stocrm.offers_by_contact(cid)
            works = stocrm.works_index([int(o.get("OFFER_ID") or 0) for o in offers if o.get("OFFER_ID")])
            for o in offers:
                mapped = _offer_out(o, works.get(int(o.get("OFFER_ID") or 0), []))
                blob = " ".join(
                    str(x)
                    for x in (
                        mapped.get("status"),
                        mapped.get("branch"),
                        mapped.get("car"),
                        " ".join(mapped.get("works") or []),
                    )
                    if x
                ).lower()
                if needle in blob:
                    hits.append(
                        {
                            "kind": "visit",
                            "title": mapped.get("status") or "Заявка",
                            "subtitle": mapped.get("branch") or "",
                            "screen": "visits",
                        }
                    )
        except Exception:
            pass
    try:
        for b in branches().get("branches") or []:
            blob = f"{b.get('name') or ''} {b.get('address') or ''} {b.get('city') or ''}".lower()
            if needle in blob:
                hits.append({"kind": "branch", "title": b.get("name") or "", "subtitle": b.get("address") or "", "screen": "branches"})
    except Exception:
        pass
    catalog = (
        ("Техническое обслуживание", "ТО-1 / ТО-2", "book"),
        ("Диагностика", "Компьютер + осмотр", "book"),
        ("Замена масла", "Моторное масло + фильтр", "book"),
        ("Шиномонтаж", "Сезонная смена комплекта", "book"),
        ("Тормозная система", "Колодки, диски", "book"),
        ("Подбор запчасти по VIN", "Заявка менеджеру", "vin"),
    )
    for title, sub, screen in catalog:
        if needle in title.lower() or needle in sub.lower():
            hits.append({"kind": "service", "title": title, "subtitle": sub, "screen": screen})
    return {"q": q, "items": hits[:20]}


@app.get("/v1/widget")
def widget_get(authorization: str | None = Header(default=None)) -> dict[str, Any]:
    """Состояние виджета: ok / due / service / ready."""
    state = "ok"
    title = "Всё в порядке"
    subtitle = "Запишитесь, когда понадобится"
    screen = "book"
    user = None
    if authorization:
        try:
            user = require_user(authorization)
        except HTTPException:
            user = None
    cid = int(user["contact_id"]) if user and user.get("contact_id") else 0
    if cid:
        try:
            offers = stocrm.offers_by_contact(cid)
            works = stocrm.works_index([int(o.get("OFFER_ID") or 0) for o in offers if o.get("OFFER_ID")])
            open_ones = []
            for o in offers:
                mapped = _offer_out(o, works.get(int(o.get("OFFER_ID") or 0), []))
                if mapped.get("is_history"):
                    continue
                open_ones.append(mapped)
            ready = [x for x in open_ones if x.get("is_ready")]
            if ready:
                state, title, subtitle, screen = "ready", "Машина готова", str(ready[0].get("status") or "заберите авто"), "status"
            elif open_ones:
                cur = open_ones[0]
                state, title, subtitle, screen = "service", "Авто в сервисе", str(cur.get("status") or "в работе"), "status"
            else:
                cars = stocrm.cars_by_contact(cid)
                for c in cars:
                    km = c.get("MILEAGE")
                    nxt = c.get("NEXT_SERVICE_KM") or c.get("TO_MILEAGE")
                    if nxt and km and int(nxt) - int(km) <= 0:
                        state, title, subtitle, screen = "due", "Пора на ТО", "Рекомендация из карточки авто", "recommendations"
                        break
        except Exception:
            pass
    return {"state": state, "title": title, "subtitle": subtitle, "screen": screen}


def _audience_ids() -> list[int]:
    ids: set[int] = set(known_contact_ids())
    for row in list_audience():
        try:
            ids.add(int(row.get("contact_id") or 0))
        except (TypeError, ValueError):
            continue
    for u in sessions.values():
        if u.get("contact_id"):
            ids.add(int(u["contact_id"]))
    return sorted(i for i in ids if i)


def _match_segment(cid: int, segment: str, branch_id: str) -> bool:
    seg = (segment or "all").strip().lower()
    if seg in ("", "all"):
        return True
    try:
        offers = stocrm.offers_by_contact(cid)
    except Exception:
        offers = []
    now = int(datetime.now().timestamp())
    last_ts = 0
    last_branch = ""
    for o in offers:
        raw = o.get("DATE_CREATE") or o.get("CREATED") or o.get("DATE") or o.get("OFFER_DATE_CREATE_FRONTEND_TIMESTAMP") or 0
        try:
            ts = int(raw)
        except (TypeError, ValueError):
            ts = 0
        if ts > 10_000_000_000:
            ts //= 1000
        if ts >= last_ts:
            last_ts = ts
            last_branch = str(o.get("CUSTOMER_ID") or o.get("customer_id") or "")
    if seg == "inactive":
        return last_ts == 0 or now - last_ts >= 90 * 86400
    if seg in ("branch", f"branch:{branch_id}") or seg.startswith("branch"):
        want = branch_id or (seg.split(":", 1)[1] if ":" in seg else "")
        if not want:
            return False
        return last_branch == str(want) or any(str(o.get("CUSTOMER_ID") or "") == str(want) for o in offers)
    return True


@app.get("/admin/")
def admin_page() -> FileResponse:
    path = Path(__file__).resolve().parent / "admin.html"
    if not path.is_file():
        raise HTTPException(404)
    return FileResponse(path)


@app.get("/admin/api/threads")
def admin_threads(x_bff_secret: str | None = Header(default=None, alias="X-BFF-Secret")) -> dict[str, Any]:
    require_admin(x_bff_secret)
    return {"threads": list_threads()}


@app.get("/admin/api/threads/{key}")
def admin_thread(key: str, x_bff_secret: str | None = Header(default=None, alias="X-BFF-Secret")) -> dict[str, Any]:
    require_admin(x_bff_secret)
    msgs = list_messages(key)
    last = msgs[-1] if msgs else {}
    return {
        "key": key,
        "messages": msgs,
        "phone": last.get("phone") or "",
        "name": last.get("name") or "",
    }


@app.post("/admin/api/threads/{key}")
def admin_reply(key: str, body: StaffReplyIn, x_bff_secret: str | None = Header(default=None, alias="X-BFF-Secret")) -> dict[str, Any]:
    require_admin(x_bff_secret)
    text = body.text.strip()
    if not text:
        raise HTTPException(400, "Пустой ответ")
    staff = body.staff_name.strip() or "Егор"
    msg = add_message(key, text=text, from_staff=True, staff_name=staff, kind="chat")
    try:
        cid = int(key)
        add_note(cid, "Новое сообщение", f"{staff}: {text[:120]}", kind="chat")
    except ValueError:
        pass
    return {"ok": True, "item": msg}


@app.get("/admin/api/vin")
def admin_vin(x_bff_secret: str | None = Header(default=None, alias="X-BFF-Secret")) -> dict[str, Any]:
    require_admin(x_bff_secret)
    return {"items": list_vin()}


@app.get("/admin/api/audience")
def admin_audience(x_bff_secret: str | None = Header(default=None, alias="X-BFF-Secret")) -> dict[str, Any]:
    require_admin(x_bff_secret)
    return {"items": list_audience(), "contact_ids": _audience_ids()}


@app.get("/admin/api/campaigns")
def admin_campaigns_get(x_bff_secret: str | None = Header(default=None, alias="X-BFF-Secret")) -> dict[str, Any]:
    require_admin(x_bff_secret)
    return {"items": list_campaigns(), "promos": list_promos()}


@app.post("/admin/api/campaigns")
def admin_campaigns_post(body: CampaignIn, x_bff_secret: str | None = Header(default=None, alias="X-BFF-Secret")) -> dict[str, Any]:
    require_admin(x_bff_secret)
    title = body.title.strip()
    text = body.body.strip()
    if not title or not text:
        raise HTTPException(400, "Нужны заголовок и текст")
    row = add_campaign(
        title=title,
        body=text,
        badge=body.badge,
        segment=body.segment,
        branch_id=body.branch_id,
        pin=body.pin,
    )
    sent = 0
    targets: list[int] = []
    for cid in _audience_ids():
        if _match_segment(cid, body.segment, body.branch_id):
            targets.append(cid)
    if not targets and body.segment in ("", "all"):
        # ещё никто не входил — положим тестовому контакту, если он в CRM-сессии появится позже
        pass
    for cid in targets:
        add_note(cid, title, text, kind="promo")
        sent += 1
    mark_campaign_sent(row["id"], sent)
    row["sent"] = sent
    return {"ok": True, "item": row, "sent": sent, "targets": targets, "fcm": bool((settings.fcm_server_key or "").strip())}


@app.get("/admin/api/shorts")
def admin_shorts_get(x_bff_secret: str | None = Header(default=None, alias="X-BFF-Secret")) -> dict[str, Any]:
    require_admin(x_bff_secret)
    return {"items": list_shorts()}


@app.post("/admin/api/shorts")
def admin_shorts_post(body: ShortIn, x_bff_secret: str | None = Header(default=None, alias="X-BFF-Secret")) -> dict[str, Any]:
    require_admin(x_bff_secret)
    title = body.title.strip()
    if not title:
        raise HTTPException(400, "Нужен заголовок ролика")
    row = add_short(title=title, subtitle=body.subtitle, url=body.url, poster=body.poster)
    return {"ok": True, "item": row}


def _offer_id(data: Any) -> int | None:
    if isinstance(data, int):
        return data
    if isinstance(data, str) and data.isdigit():
        return int(data)
    if isinstance(data, dict):
        resp = data.get("RESPONSE", data)
        if isinstance(resp, int):
            return resp
        if isinstance(resp, str) and resp.isdigit():
            return int(resp)
        if isinstance(resp, dict):
            raw = resp.get("OFFER_ID") or resp.get("ID")
            if raw is not None and str(raw).isdigit():
                return int(raw)
    return None


def _phone_out(raw: Any) -> str:
    if raw is None or raw is False:
        return ""
    if isinstance(raw, str):
        return raw
    if isinstance(raw, dict):
        return _phone_out(list(raw.values()))
    if isinstance(raw, list):
        parts: list[str] = []
        for x in raw:
            if isinstance(x, dict):
                parts.append(str(x.get("VALUE") or x.get("PHONE") or x.get("NUMBER") or x.get("phone") or ""))
            else:
                parts.append(str(x))
        return ", ".join(p for p in parts if p and p not in ("False", "None"))
    return str(raw)


def _work_time_out(raw: Any) -> str:
    if raw is None or raw is False:
        return ""
    if isinstance(raw, str):
        return raw
    if isinstance(raw, dict):
        return str(raw.get("TEXT") or raw.get("TITLE") or "")
    return str(raw)


def _maps_url(address: str, name: str, city: str) -> str:
    q = " ".join(x for x in (city or "Тюмень", address or name) if x).strip()
    return f"https://2gis.ru/tyumen/search/{quote(q)}"


if settings.serve_site:
    mount_site(app)

